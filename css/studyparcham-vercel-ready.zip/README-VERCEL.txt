VERCEL DEPLOYMENT

This project is configured as a static Vercel site.
API requests to /api/* are proxied to:
https://studyparcham.in/api/*

Important:
- The original ZIP does not contain data/all_batches.json although index.html requests it.
- If that file exists on the original site, copy it into /data/all_batches.json before deployment.
- Existing external APIs and Firebase configuration are preserved.
